﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace DemoApp.Models
{
    public class BlogDbContext : DbContext
    {
        public BlogDbContext()
           : base("DefaultConnection")
        {
        }

        public DbSet<Blog> Blogs { get; set; }
    }
}