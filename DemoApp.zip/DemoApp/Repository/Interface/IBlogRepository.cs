﻿using DemoApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApp.Repository
{
    public interface IBlogRepository : IRepository
    {
        Blog Create(Blog blog);
        Blog Get(int id);
        IEnumerable<Blog> GetAll();
        void Delete(Blog blog);
        void Update(Blog blog);
    }
}
