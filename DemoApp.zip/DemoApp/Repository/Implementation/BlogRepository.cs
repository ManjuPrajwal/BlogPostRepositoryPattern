﻿using DemoApp.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace DemoApp.Repository
{
    public class BlogRepository : IBlogRepository
    {
        private readonly BlogDbContext db;
        public BlogRepository()
        {
            db = new BlogDbContext();
        }
        public Blog Create(Blog blog)
        {
            var result = db.Blogs.Add(blog);
            db.SaveChanges();
            return result;
        }

        public void Delete(Blog blog)
        {
            db.Blogs.Remove(blog);
            db.SaveChanges();
        }

        public Blog Get(int id)
        {
            return db.Blogs.Find(id);
        }

        public IEnumerable<Blog> GetAll()
        {
            return db.Blogs.ToList();
        }

        public void Update(Blog blog)
        {
            db.Entry(blog).State = EntityState.Modified;
            db.SaveChanges();
        }
    }
}