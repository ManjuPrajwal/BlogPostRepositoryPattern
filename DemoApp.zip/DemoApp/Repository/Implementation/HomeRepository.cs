﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoApp.Repository
{
    public class HomeRepository : IHomeRepository
    {
        public string GetName(string name)
        {
            return name + " custom";
        }
    }
}