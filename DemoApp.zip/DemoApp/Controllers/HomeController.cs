﻿using DemoApp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DemoApp.Controllers
{
    public class HomeController : Controller
    {
        public IHomeRepository HomeRepository { get; }

        public HomeController(IHomeRepository homeRepository)
        {
            HomeRepository = homeRepository;
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = HomeRepository.GetName("Manju");

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Contact US.";

            return View();
        }
    }
}