﻿using Autofac;
using Autofac.Builder;
using Autofac.Core;
using Autofac.Integration.Mvc;
using DemoApp.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;

namespace DemoApp.App_Start
{
    public class DependancyResolverConfig
    {
        public static void Register()
        {
            ////Initialize builder
            var builder = new ContainerBuilder();

            builder.RegisterSource(new ViewRegistrationSource());
            builder.RegisterModule<AutofacWebTypesModule>();
            builder.RegisterControllers(typeof(MvcApplication).Assembly);

            // Register repository
            builder.RegisterAssemblyTypes(typeof(MvcApplication).Assembly)
                .Where(m => m.IsClass && !m.IsAbstract && typeof(IRepository).IsAssignableFrom(m))
                .AsImplementedInterfaces()
                .InstancePerRequest();

            //builder.RegisterType<HomeRepository>().As<IHomeRepository>().InstancePerLifetimeScope();
            //builder.RegisterType<BlogRepository>().As<IBlogRepository>().InstancePerLifetimeScope();

            //Build
            DependencyResolver.SetResolver(new AutofacDependencyResolver(builder.Build()));

        }

    }
    
}