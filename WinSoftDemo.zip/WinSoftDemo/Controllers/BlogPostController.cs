﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WinSoftDemo.Models;

namespace WinSoftDemo.Controllers
{
    public class BlogPostController : Controller
    {
        // GET: BlogPost

        public ActionResult Index()
        {
            DepartmentDbhandle dbhandle = new DepartmentDbhandle();
            ModelState.Clear();
            return View(dbhandle.GetBlogDetails());

        }

        [HttpGet]
        public ActionResult BlogPost()
        {
            return View();
        }
        public ActionResult BlogPost(BlogPost ImageContent)
        {
            if (ImageContent.ImageFile.ContentLength > (5 * 1024 * 1024))
            {
                ModelState.AddModelError("CustomError", "File size must be less than 5 MB");
                return View();
            }

            string FileName = Path.GetFileNameWithoutExtension(ImageContent.ImageFile.FileName);

            //To Get File Extension
            string FileExtension = Path.GetExtension(ImageContent.ImageFile.FileName);

            string ext = Path.GetExtension(ImageContent.ImageFile.FileName);

            //if (ext != ".jpg" || ext != ".png" || ext != ".gif" || ext != ".jpeg")
            //{
            //    ModelState.AddModelError("CustomError", "Please choose only .jpg, .png and .gif image types!");
            //    return View();
            //    // Page.ClientScript.RegisterClientScriptBlock(typeof(Page), "Alert", "alert('Please choose only .jpg, .png and .gif image types!')", true);
            //}

            //ADD CURRENT DATE TO ATTACHED FILE NAME
            FileName = DateTime.Now.ToString("yyyyMMdd") + "-" + FileName.Trim() + FileExtension;

            //GET UPLOAD PATH FROM WEB.CONFIG FILE APPSETTINGS.
            string UploadPath = ConfigurationManager.AppSettings["UserImagePath"].ToString();

            //ITS CREATE COMPLETE PATH TO STORE IN SERVER.
            ImageContent.ImagePath = UploadPath + FileName;

            //TO COPY AND SAVE FILE INTO SERVER.
            ImageContent.ImageFile.SaveAs(ImageContent.ImagePath);
            

            DepartmentDbhandle sdb = new DepartmentDbhandle();
            if (sdb.AddDepartment(ImageContent))
            {
                ViewBag.Message = "Blog Post Details Added Successfully";
                ModelState.Clear();
            }
            return View();
        }
    }
}


