﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WinSoftDemo.Models;

namespace WinSoftDemo.Controllers
{
    public class DepartmentController : Controller
    {
        // GET: Department
        //public ActionResult Index()
        //{
        //    DepartmentDbhandle dbhandle = new DepartmentDbhandle();
        //    ModelState.Clear();
        //     return View(dbhandle.GetDepartment());
            
        //}

        // GET: Department/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Department/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Department/Create
        [HttpPost]
        public ActionResult Create(BlogPost smodel)
        {
            try
            {
                //if (ModelState.IsValid)
                //{
                    DepartmentDbhandle sdb = new DepartmentDbhandle();
                    if (sdb.AddDepartment(smodel))
                    {
                        ViewBag.Message = "Student Details Added Successfully";
                        ModelState.Clear();
                    }
                //}
                return View();
            }
            catch (Exception ex)
            {
                throw ex;

            }
        }

        // GET: Department/Edit/5
        //public ActionResult Edit(int id)
        //{
        //    DepartmentDbhandle sdb = new DepartmentDbhandle();
        //    return View(sdb.GetDepartment().Find(smodel => smodel.Id == id));
        //}

        // POST: Department/Edit/5
        //[HttpPost]
        //public ActionResult Edit(int id, DepartMent smodel)
        //{
        //    try
        //    {
        //        DepartmentDbhandle sdb = new DepartmentDbhandle();
        //        sdb.UpdateDetails(smodel);
        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}

        // GET: Department/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Department/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult CreateBlog(BlogPost ImageContent)
        {//Use Namespace called :  System.IO
            string FileName = Path.GetFileNameWithoutExtension(ImageContent.ImageFile.FileName);

            //To Get File Extension
            string FileExtension = Path.GetExtension(ImageContent.ImageFile.FileName);

            //Add Current Date To Attached File Name
            FileName = DateTime.Now.ToString("yyyyMMdd") + "-" + FileName.Trim() + FileExtension;

            //Get Upload path from Web.Config file AppSettings.
            string UploadPath = ConfigurationManager.AppSettings["UserImagePath"].ToString();

            //Its Create complete path to store in server.
            ImageContent.ImagePath = UploadPath + FileName;

            //To copy and save file into server.
            ImageContent.ImageFile.SaveAs(ImageContent.ImagePath);

            DepartmentDbhandle sdb = new DepartmentDbhandle();
            if (sdb.AddDepartment(ImageContent))
            {
                ViewBag.Message = "Student Details Added Successfully";
                ModelState.Clear();
            }
            return View();


        }
    }
}
